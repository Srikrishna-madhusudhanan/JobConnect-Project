import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Jobs')

def lambda_handler(event, context):
    try:
        table.put_item(
            Item={
                                "Login_Id":event["Login_Id"],
                                "Job_Id":event["Job_Id"],
                                "JobType":event["JobType"].upper(),
                                "Job_Openings":event["Job_Openings"],
                                "DateFrom":event["DateFrom"],
                                "DateTo":event["DateTo"],
                                "Job_Description":event["Job_Description"],
                                "Job_Status":event["Job_Status"],
                                "Job_Address_City":event["Job_Address_City"],
                                "Job_Address_Pincode":event["Job_Address_Pincode"],
                                "Job_Address_State":event["Job_Address_State"],
                                "Job_Address_Street":event["Job_Address_Street"],
                                "Lattitude":event["Lattitude"],
                                "Longtitude":event["Longtitude"],
                                "Payment_Frequency":event["Payment_Frequency"],
                                "Wage_Minimum":event["Wage_Minimum"],
                                "Wage_Maximum":event["Wage_Maximum"],
                                "Name_JP": event["Name_JP"],
                                "Mobile_Number_JP":event["Mobile_Number_JP"],
                                "Email_JP": event["Email_JP"]
                            }
                      )
                      
    except Exception as e:
        raise
        return {
              "statusCode": 210,
              "body": json.dumps({"Login_Id": event["Login_Id"], "Job_Id":event["Job_Id"], "newjob_Status": "Job not added"})
               }
    table2 = dynamodb.Table('Job_Types')
    table2.put_item( Item={ "Job_Type":event["JobType"].upper()})
    return {
        'statusCode': 200,
        'body': json.dumps({"Login_Id": event["Login_Id"], "Job_Id":event["Job_Id"], "newjob_Status": "Job added"})
    }
    