import json
import boto3
from boto3.dynamodb.conditions import Key, Attr

# Get the service resource.
dynamodb = boto3.resource('dynamodb', 'ap-south-1')
job_table = dynamodb.Table('Jobs')
jobprogress_table = dynamodb.Table('Job_Progress')
allJobsFilter = ["ALL", "All", "all"]
Job_Progress_Status_List = ["REQUESTED", "ACCEPTED", "REQUEST_CANCELLED", "ACCEPT_CANCELLED", "DECLINED"]
Job_Status_List = ["AVAILABLE", "READY", "DELETED"]

def lambda_handler(event, context):
    items = {}
    try:
        if event["Login_Type"] == "JP" and (event["Job_Status"] in Job_Status_List):
                if len(event["Jobs_Filter"]) == 0 or (allJobsFilter in event["Jobs_Filter"]):
                    SetFilterExpression= Key('Login_Id').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"])
                else:
                    SetFilterExpression= Key('Login_Id').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_Type').is_in(event["Jobs_Filter"])
                response = job_table.scan(FilterExpression = SetFilterExpression )
                if 'Items' in response:
                    items = response['Items']
                    while 'LastEvaluatedKey' in response:
                        response = job_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                        items.extend(response['Items'])
        elif event["Login_Type"] == "JP" and (event["Job_Status"] in Job_Progress_Status_List):
                if len(event["Jobs_Filter"]) == 0 or (allJobsFilter in event["Jobs_Filter"]):
                    SetFilterExpression= Attr('Login_Id_JS').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"])
                else:
                    SetFilterExpression= Attr('Login_Id_JS').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_Type').is_in(event["Jobs_Filter"])
                response = jobprogress_table.scan(
                            FilterExpression= SetFilterExpression
                            )
                if 'Items' in response:
                    items = response['Items']
                    while 'LastEvaluatedKey' in response:
                        response = jobprogress_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                        items.extend(response['Items'])
        elif event["Login_Type"] == "JS" and event["Job_Status"] == "AVAILABLE":
                if len(event["Jobs_Filter"]) == 0 or allJobsFilter in event["Jobs_Filter"]:
                   SetFilterExpression= Attr('Job_Status').eq(event["Job_Status"])
                   if len(event["City_Filter"]) > 0 and allJobsFilter not in event["City_Filter"]:
                      SetFilterExpression= Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_City').is_in(event["City_Filter"])
                else:
                    SetFilterExpression= Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_Type').is_in(event["Jobs_Filter"]) 
                    if len(event["City_Filter"]) > 0 and allJobsFilter not in event["City_Filter"]:
                        SetFilterExpression= Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_Type').is_in(event["Jobs_Filter"]) &Attr('Job_City').is_in(event["City_Filter"])
                response = job_table.scan(FilterExpression= SetFilterExpression)
                if 'Items' in response:
                    items = response['Items']
                    while 'LastEvaluatedKey' in response:
                        response = job_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                        items.extend(response['Items'])
        elif event["Login_Type"] == "JS" and (event["Job_Status"] in Job_Progress_Status_List):
                if len(event["Jobs_Filter"]) == 0 or allJobsFilter in event["Jobs_Filter"]:
                    SetFilterExpression= Key('Login_Id_JS').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"])
                else:
                    SetFilterExpression= Key('Login_Id_JS').eq(event["Login_Id"]) & Attr('Job_Status').eq(event["Job_Status"]) & Attr('Job_Type').is_in(event["Jobs_Filter"])
                response = jobprogress_table.scan(
                            FilterExpression= SetFilterExpression
                            )
                if 'Items' in response:
                    items = response['Items']
                    while 'LastEvaluatedKey' in response:
                        response = jobprogress_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                        items.extend(response['Items'])
    except Exception as e:
        if e.__class__.__name__ == 'ResourceInUseException':
            pass
        else:
            raise
            return {
                  "statusCode": 210,
                  "body": json.dumps({"Status": "Jobs not found", "Job_Filter": event["Jobs_Filter"]})
                   }
    return {
        "statusCode": 200,
        "body": json.dumps({"Status": "Success", "Jobs_List": items})
        }