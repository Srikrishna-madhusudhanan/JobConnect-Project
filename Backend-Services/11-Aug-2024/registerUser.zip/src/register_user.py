import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Users')

def lambda_handler(event, context):
    # TODO implement
    try:
        response = table.put_item(
                        Item={
                                "Login_Id": event["Login_Id"],
                                "Login_Type": event["Login_Type"].upper(),
                                "Mobile_Number":  event["Mobile_Number"],
                                "Password": event["Password"],
                                "User_Name":event["User_Name"],
                                "Gender": event["Gender"].upper(),
                                "Age":event["Age"],
                                "Profession":event["Profession"].upper(),
                                "Experience_Years": event["Experience_Years"],
                                "Experience_Months": event["Experience_Months"],
                                "Average_Rating": event["Average_Rating"],
                                "Street": event["Street"],
                                "City": event["City"].upper(),
                                "State": event["State"].upper(),
                                "Pincode": event["Pincode"],
                                "Email": event["Email"],
                                "Email_Status": "UNVERIFIED",
                                "Access_Code":"234"
                            },
                            ConditionExpression='attribute_not_exists(Login_Id)'
                      )
    except Exception as e:
        if e.__class__.__name__ == 'ConditionalCheckFailedException':
            return {
                  "statusCode": 202,
                  "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "User Already Exist"})
                   }
        else:
            raise

    return {
        'statusCode': 201,
        'body': json.dumps({"Login_Id": event["Login_Id"], "Status": "User Added"})
           }