import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
job_progress_table = dynamodb.Table('Job_Progress')
from boto3.dynamodb.conditions import Key
jobs_table = dynamodb.Table('Jobs')

client = boto3.client('ses', region_name='ap-south-1')

def sendEmail(Email_JP,  Email_JS, Job_Id):
            response = client.send_email(
                            Destination={
                                'ToAddresses': [Email_JP, Email_JS]
                            },
                            Message={
                                'Body': {
                                    'Text': {
                                        'Charset': 'UTF-8',
                                        'Data': 'There is an update on the Job posting id : ' + Job_Id + '. Please check the JobConnect App for further details.',
                                    }
                                },
                                'Subject': {
                                    'Charset': 'UTF-8',
                                    'Data': 'Job Id ' + Job_Id + ' update from JobConnect',
                                },
                            },
                            Source="JobConnects@protonmail.com"
                            )

def lambda_handler(event, context):
    # TODO implement
    if event["Job_Status"].upper() == "REQUESTED":
            try:
                job_progress_table.put_item(
                                Item={
                                        "Job_Id": event["Job_Id"],
                                        "Login_Id_JS": event["Login_Id_JS"],
                                        "Login_Id_JP": event["Login_Id_JP"],
                                        "Mobile_Number_JS": event["Mobile_Number_JS"],
                                        "Mobile_Number_JP": event["Mobile_Number_JP"],
                                        "DateFrom": event["DateFrom"],
                                        "DateTo": event["DateTo"],
                                        "Job_Address_Pincode": event["Job_Address_Pincode"],
                                        "Job_Type": event["Job_Type"].upper(),
                                        "Job_Status": event["Job_Status"].upper(),
                                        "Name_JP": event["Name_JP"],
                                        "Name_JS": event["Name_JS"],
                                        "Payment_Frequency": event["Payment_Frequency"],
                                        "Requested Wage": event["Requested Wage"],
                                        "Wage_Maximum": event["Wage_Maximum"],
                                        "Email_JP": event["Email_JP"],
                                        "Email_JS": event["Email_JS"],
                                        "Lattitude": event["Lattitude"], 
                                        "Longtitude": event["Longtitude"]
                                    }
                              )
            except KeyError:
                raise
                return {
                      "statusCode": 210,
                      "body": json.dumps({"Job_Id": event["Job_Id"], "Job_Progress_Status": "Job Progress not added"})
                       }
    elif event["Job_Status"].upper() != "REQUESTED" and event["Job_Status"].upper() != "DELETED":
            try:    
                job_progress_table.update_item( Key={'Job_Id': event['Job_Id'], 'Login_Id_JS': event['Login_Id_JS'] },
                                UpdateExpression='SET Job_Status = :val1',
                                ExpressionAttributeValues={ ':val1': event["Job_Status"].upper()}
                                  )
                response = jobs_table.get_item(  Key={"Login_Id": event["Login_Id_JP"], "Job_Id": event["Job_Id"] } )
                item = response['Item']
                
                if event["Job_Status"].upper() == "ACCEPTED":
                    job_count = int(item["Job_Openings"]) - 1
                elif event["Job_Status"].upper() == "ACCEPT_CANCELLED":
                    job_count = int(item["Job_Openings"]) + 1
                if event["Job_Status"].upper() == "ACCEPTED" or event["Job_Status"].upper() == "ACCEPT_CANCELLED":
                    response = jobs_table.get_item( Key={ "Login_Id": event["Login_Id_JP"], "Job_Id": event["Job_Id"] } )
                    item = response['Item']
                    jobs_table.update_item( Key={"Login_Id": event["Login_Id_JP"], "Job_Id": event["Job_Id"] },
                                                    UpdateExpression='SET Job_Openings = :val1',
                                                    ExpressionAttributeValues={ ':val1': str(job_count) }
                                          )
            except KeyError:
                raise
                return {
                      "statusCode": 210,
                      "body": json.dumps({"Job_Id": event["Job_Id"], "Job_Progress_Status": "Job Progress not updated in all placess"})
                       }
    elif event["Job_Status"].upper() == "DELETED":
            try:
                jobs_table.update_item( Key={'Login_Id': event['Login_Id_JP'], 'Job_Id': event['Job_Id'] },
                                                UpdateExpression='SET Job_Status = :val1',
                                                ExpressionAttributeValues={ ':val1': event["Job_Status"].upper()}
                                      )
                response = job_progress_table.query( KeyConditionExpression =Key('Job_Id').eq(event['Job_Id']), ProjectionExpression = 'Login_Id_JS' )
                items = response['Items']
                for item in items:
                    job_progress_table.update_item( Key={'Job_Id': event['Job_Id'], 'Login_Id_JS': item["Login_Id_JS"] }, UpdateExpression='SET Job_Status = :val1',
                                                ExpressionAttributeValues={ ':val1': event["Job_Status"].upper()} )              
            except KeyError:
                raise
                return {
                      "statusCode": 210,
                      "body": json.dumps({"Job_Id": event["Job_Id"], "Job_Progress_Status": "Job Progress not updated in all placess"})
                       }      
    
    sendEmail(event["Email_JP"], event["Email_JS"], event["Job_Id"])
    return {
        'statusCode': 200,
        'body': json.dumps({"Job_Id": event["Job_Id"], "Job_Status": event["Job_Status"], "Job_Progress": "Job Progress Updated"})
           }